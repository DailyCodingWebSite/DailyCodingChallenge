document.addEventListener('DOMContentLoaded', () => {
    const questionsList = document.getElementById('questionsList');
    const usersList = document.getElementById('usersList');

    // Fetch questions
    fetch('/questions')
        .then(res => res.json())
        .then(questions => {
            questionsList.innerHTML = '';
            questions.forEach(q => {
                const li = document.createElement('li');
                li.textContent = `${q.text} (Answer: ${q.answer})`;
                questionsList.appendChild(li);
            });
        });

    // Fetch users
    fetch('/users')
        .then(res => res.json())
        .then(users => {
            usersList.innerHTML = '';
            users.forEach(u => {
                const li = document.createElement('li');
                li.textContent = `${u.username} (${u.role})`;
                usersList.appendChild(li);
            });
        });
});

// Example: Add a question
function addQuestion() {
    const text = prompt("Enter question text:");
    const options = {
        A: prompt("Option A:"),
        B: prompt("Option B:"),
        C: prompt("Option C:"),
        D: prompt("Option D:")
    };
    const answer = prompt("Correct option (A/B/C/D):");

    fetch('/questions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text, options, answer })
    })
    .then(res => res.json())
    .then(data => {
        alert("Question added!");
        location.reload();
    });
}

// Logout
function logout() {
    window.location.href = 'index.html';
}
