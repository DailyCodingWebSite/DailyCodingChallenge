document.addEventListener('DOMContentLoaded', () => {
    const facultyName = document.getElementById('facultyName');
    const statsContainer = document.getElementById('statsContainer');
    const attemptsTable = document.getElementById('attemptsTable');

    // Example faculty name
    facultyName.textContent = "Welcome, Faculty!";

    // Fetch attempts from backend
    fetch('/attempts')
        .then(res => res.json())
        .then(attempts => {
            if (attempts.length === 0) {
                statsContainer.innerHTML = "<p>No quiz attempts yet.</p>";
                return;
            }

            // Statistics
            const totalStudents = new Set(attempts.map(a => a.username)).size;
            const avgScore = (attempts.reduce((sum, a) => sum + a.score, 0) / attempts.length).toFixed(2);
            const completionRate = ((attempts.length / totalStudents) * 100).toFixed(0);

            statsContainer.innerHTML = `
                <p>Total Students: ${totalStudents}</p>
                <p>Average Score: ${avgScore}</p>
                <p>Completion Rate: ${completionRate}%</p>
            `;

            // Fill attempts table
            attempts.forEach(a => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${a.username}</td>
                    <td>${a.class || 'CSE-A'}</td>
                    <td>${new Date(a.date).toLocaleDateString()}</td>
                    <td>${a.score}</td>
                `;
                attemptsTable.appendChild(row);
            });
        });
});

// Logout example
function logout() {
    window.location.href = 'index.html';
}
