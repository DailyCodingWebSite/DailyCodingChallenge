document.addEventListener('DOMContentLoaded', async () => {
    const quizContainer = document.getElementById('quizContainer');

    if (quizContainer) {
        const response = await fetch('/get-today-quiz');
        const data = await response.json();

        if (!data.available) {
            quizContainer.innerHTML = '<p>No quiz available today.</p>';
            return;
        }

        const questions = data.questions;
        let html = '<form id="quizForm">';
        questions.forEach((q, index) => {
            html += `<p>${index + 1}. ${q.text}</p>`;
            q.options.forEach(opt => {
                html += `<input type="radio" name="q${q.id}" value="${opt}" required /> ${opt}<br>`;
            });
        });
        html += '<button type="submit">Submit</button></form>';
        quizContainer.innerHTML = html;

        const quizForm = document.getElementById('quizForm');
        quizForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(quizForm);
            const answers = questions.map(q => ({ id: q.id, answer: formData.get(`q${q.id}`) }));

            const res = await fetch('/submit-quiz', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ answers })
            });

            const result = await res.json();
            if (result.success) alert(`Quiz submitted! Your score: ${result.score}`);
            else alert(result.message);
        });
    }
});
