document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const role = document.getElementById('role').value;

            if (!role) {
                alert('Please select a role');
                return;
            }

            const response = await fetch('/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, role })
            });

            const data = await response.json();

            if (data.success) {
                if (data.role === 'admin') window.location.href = 'admin.html';
                else if (data.role === 'faculty') window.location.href = 'faculty.html';
                else if (data.role === 'student') window.location.href = 'student.html';
            } else {
                document.getElementById('error-message').textContent = data.message || 'Login failed';
            }
        });
    }
});
